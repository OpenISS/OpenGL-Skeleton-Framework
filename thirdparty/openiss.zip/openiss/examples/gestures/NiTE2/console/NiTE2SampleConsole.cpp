//
// Created by jash on 25/01/19.
//

#ifdef OPENISS_NITE2_SUPPORT
#include "OINiTEGestureTracker.hpp"
#endif

#include "OINullGestureTracker.hpp"

using namespace openiss;

int main(int argc, char** argv)
{
#ifdef OPENISS_NITE2_SUPPORT
  OIGestureTracker* gesture_tracker = new OINiTEGestureTracker();
#else
  OIGestureTracker* gesture_tracker = new OINullGestureTracker();
#endif

  gesture_tracker->init();
  gesture_tracker->startGestureDetection();

  while(true)
  {
    gesture_tracker->update();
    auto gestures = gesture_tracker->getGestures();
    auto hands = gesture_tracker->getHands();

    for(auto gesture : gestures)
    {
      std::cout << "Detected gesture of type : " << gesture.getGestureType() << std::endl;
    }

    for(auto hand : hands)
    {
      if(hand.isHandTracked())
        std::cout << "Tracking hand with id : " << hand.getHandID() << std::endl;
    }
  }
  return 0;
}

// EOF
