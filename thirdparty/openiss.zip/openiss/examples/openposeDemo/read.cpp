#include "read.h"

read::read()
{
}


read::~read()
{
}
