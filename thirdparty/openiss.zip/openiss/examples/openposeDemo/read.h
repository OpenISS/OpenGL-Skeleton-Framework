#pragma once
class read
{
public:
	read();
	~read();
};

