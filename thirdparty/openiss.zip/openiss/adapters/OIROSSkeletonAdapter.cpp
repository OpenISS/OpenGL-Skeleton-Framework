//
//  OIROSSkeletonAdapter.cpp
//
//  Created by Jashanjot Singh on 2018-08-01
#include "OIROSSkeletonAdapter.hpp"

// TODO

// EOF