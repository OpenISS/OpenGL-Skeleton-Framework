#ifndef OPENISS_DYNAMIC_NULL_SKELETON_TRACKER_H
#define OPENISS_DYNAMIC_NULL_SKELETON_TRACKER_H

#include <iostream>
#include <unordered_map>
#include <vector>

#include "OISkeletonTracker.hpp"

namespace openiss
{

/**
 * Dynamic skeleton tracker for developlment and testing.
 * Provides stub skeleton data of a looping "snow angel" animation in the proper format.
 * @author Mark Beiline
 */
class OIDynamicNullSkeletonTracker : public OISkeletonTracker
{
public:
    explicit OIDynamicNullSkeletonTracker(OIDevice& pDev);
    ~OIDynamicNullSkeletonTracker();

    OIStatus init() override;
    OIStatus update() override;
    OIStatus stop() override;

    void startTracking() override;
    void stopTracking() override;

    OITrackerFrame* readFrame(OITrackerFrame*) override;

    void mapJoint2Depth(float x, float y, float z, float* pOutX, float* pOutY) const override;
    void mapDepth2Joint(int x, int y, int z, float* pOutX, float* pOutY) const override;

private:
    // disable copy constructor and copy assignment
    OIDynamicNullSkeletonTracker(const OIDynamicNullSkeletonTracker&);
    OIDynamicNullSkeletonTracker& operator=(OIDynamicNullSkeletonTracker&);
};

class OIDynamicNullTrackerFrame : public OITrackerFrame 
{
public:
    OIDynamicNullTrackerFrame();
    ~OIDynamicNullTrackerFrame();
    void update();

protected:
    OIDynamicNullTrackerFrame(const OIDynamicNullTrackerFrame& frame);
    OIDynamicNullTrackerFrame& operator = (const OIDynamicNullTrackerFrame& frame);
};

} // end of namespace

#endif // OPENISS_DYNAMIC_NULL_SKELETON_TRACKER_H
