//
//  OIROSSkeletonAdapter.hpp
//  ROS Adapter
//
//  Created by Jashanjot Singh on 2018-08-01

#include "OISkeletonTracker.hpp"

namespace openiss
{

class OIROSSkeletonAdapter : public OISkeletonTracker
{
    // TODO
};

} // namespace openiss

// EOF
