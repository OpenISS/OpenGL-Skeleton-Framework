//
// Created by Haotao Lai on 13/02/19.
//

#ifndef OPENISS_DETECTOR_H
#define OPENISS_DETECTOR_H

#include "OIClassifier.hpp"

namespace openiss
{

class OIDetector : public OIClassifier
{
public:
    virtual ~OIDetector() = default;

};


} // end of namespace

#endif // OPENISS_DETECTOR_H
