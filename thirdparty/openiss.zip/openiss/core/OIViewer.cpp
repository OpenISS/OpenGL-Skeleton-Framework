// TODO: Generic Viewer Framework
// There will be OpenGL 2, OpenGL 3, and OpenCV viewers to start

#include "OIViewer.hpp"