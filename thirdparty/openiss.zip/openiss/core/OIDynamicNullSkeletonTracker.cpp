#include "OIDevice.hpp"
#include "OIDynamicNullSkeletonTracker.hpp"
#include "OIUser.hpp"
#include "OITools.hpp"

#include <algorithm>
#include <chrono>

namespace openiss
{

// /////////////////////////////////////////////////////////////////////////////
// OIDynamicNullSkeletonTracker class implementation
// /////////////////////////////////////////////////////////////////////////////

std::chrono::system_clock::time_point m_timeStart;

OIDynamicNullSkeletonTracker::OIDynamicNullSkeletonTracker(OIDevice& pDev)
{
    //mStatus = mpTracker->create((openni::Device*) pDev.rawDevice());
    //OIUtilities::checkStatus(mStatus, "cannot create user tracker");
    std::cout << "OpenISS dynamic null skeleton tracker instantiated..." << std::endl;
    this->m_eStatus = OIStatus::STATUS_DEFAULT;
}

OIDynamicNullSkeletonTracker::~OIDynamicNullSkeletonTracker()
{
    std::cout << "OpenISS dynamic null skeleton tracker destroyed..." << std::endl;
}

OIStatus OIDynamicNullSkeletonTracker::init()
{
    m_timeStart = std::chrono::system_clock::now();

    this->m_eStatus = OIStatus::STATUS_OK;
    std::cout << "OIDynamicNullSkeletonTracker initalized..." << std::endl;
    return this->m_eStatus;
}

OIStatus OIDynamicNullSkeletonTracker::update()
{
    std::cout << "OIDynamicNullSkeletonTracker initalized..." << std::endl;
    return this->m_eStatus;
}

OIStatus OIDynamicNullSkeletonTracker::stop()
{
    std::cout << "OIDynamicNullSkeletonTracker fully stopped..." << std::endl;
    return this->m_eStatus;
}

void OIDynamicNullSkeletonTracker::startTracking()
{
    std::cout << "OIDynamicNullSkeletonTracker::startTracking() called..." << std::endl;
}

void OIDynamicNullSkeletonTracker::stopTracking()
{
    std::cout << "OIDynamicNullSkeletonTracker::stopTracking() called..." << std::endl;
}

OITrackerFrame* OIDynamicNullSkeletonTracker::readFrame(OITrackerFrame* p_poTrackerFrame)
{
#ifdef OPENISS_DEBUG
    std::cout << "OIDynamicNullSkeletonTracker::readFrame() called..." << std::endl;
    std::cout << "  p_poTrackerFrame = " << p_poTrackerFrame << std::endl;
#endif

    OITrackerFrame* l_poFrame = p_poTrackerFrame;

    if (l_poFrame == nullptr)
    {
        OITrackerFactory l_oFactory;
        l_poFrame = l_oFactory.createTrackerFrame("nullDynamic").get();
    }
	
	auto pFrame = dynamic_cast<OIDynamicNullTrackerFrame*>(l_poFrame);
    pFrame->update();

    return l_poFrame;
}

void OIDynamicNullSkeletonTracker::mapJoint2Depth
(
    float x,
    float y,
    float z,
    float* p_pfOutX,
    float* p_pfOutY
) const
{
#ifdef OPENISS_DEBUG
    std::cout
        << "OIDynamicNullSkeletonTracker::mapJoint2Depth("
        << "x = " << x << ", "
        << "y = " << y << ", "
        << "z = " << z << ", "
        << "p_pfOutX = " << p_pfOutX << ", "
        << "p_pfOutY = " << p_pfOutY
        << ")" << std::endl;
#endif 

    *p_pfOutX = x;
    *p_pfOutY = y;
}

void OIDynamicNullSkeletonTracker::mapDepth2Joint
(
    int x,
    int y,
    int z,
    float* p_pfOutX,
    float* p_pfOutY
) const
{
#ifdef OPENISS_DEBUG
    std::cout
        << "OIDynamicNullSkeletonTracker::mapDepth2Joint("
        << "x = " << x << ", "
        << "y = " << y << ", "
        << "z = " << z << ", "
        << "p_pfOutX = " << p_pfOutX << ", "
        << "p_pfOutY = " << p_pfOutY
        << ")" << std::endl;
#endif 

    *p_pfOutX = x;
    *p_pfOutY = y;
}

// /////////////////////////////////////////////////////////////////////////////
// OIDynamicNullTrackerFrame class implementation
// /////////////////////////////////////////////////////////////////////////////

OIDynamicNullTrackerFrame::OIDynamicNullTrackerFrame()
{
    prepareSupportedJoints();
    update();
    std::cout << "OIDynamicNullTrackerFrame called and prepared supported joints..." << std::endl;
}

OIDynamicNullTrackerFrame::~OIDynamicNullTrackerFrame()
{
    delete mpOIUserMap;
    std::cout << "OIDynamicNullTrackerFrame destroyed..." << std::endl;
}

void OIDynamicNullTrackerFrame::update()
{
    // update OIUserData

    // Elapsed time since device start
    std::chrono::system_clock::time_point current = std::chrono::system_clock::now();
    float elapsedSeconds = static_cast<float>(std::chrono::duration_cast<std::chrono::milliseconds>(current - m_timeStart).count()) / 1000.0f;

    // Assuming user ID 0 (1 user)
    int l_iDefaultUserID = 0;
    shared_ptr<OIUserData> l_pOIUser(new OIUserData(l_iDefaultUserID));
    mAvailableUsers.insert({l_iDefaultUserID, l_pOIUser});

    shared_ptr<OIUserData> pOIUserData = mAvailableUsers[l_iDefaultUserID];
    OISkeleton* pOISkeleton = pOIUserData->getSkeleton();

    // update bounding box and center point
    Point3f* centerPoint = pOIUserData->getCenterOfMass();

    // Simulated frame dimensions
    float frameWidth = 640.0f;
    float frameHeight = 480.0f;

    // Simulated center of mass (TORSO joint)
    centerPoint->x = 0.0f;
    centerPoint->y = 1.25f;
    centerPoint->z = 0.0f;

    // Simulated bounding box
    Point3f* bdBox = pOIUserData->getBoundingBox();
    bdBox[0].x = 0.0;
    bdBox[0].y = 0.0;
    bdBox[0].z = 0.0;
    bdBox[1].x = 0.0;
    bdBox[1].y = 0.0;
    bdBox[1].z = 0.0;

    // For now
    //   - row and column are in OpenCV-like coordinates (top down)
    //   - x, y, and z are in OpenGL-like coordinates (bottom up)

    const float pi = 3.14159265;
    const float animationFactor = (sin(elapsedSeconds) + 1.0f) * 0.5f; // Sweeps back and forth between 0 and 1

    pOISkeleton->addJointByType
    (
        JOINT_HEAD,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            0.0f, 2.33f, 0.0f,
            JOINT_HEAD
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_NECK,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            0.0f, 2.0f, 0.0f,
            JOINT_NECK
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_LEFT_SHOULDER,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            -0.33f, 2.0f, 0.0f,
            JOINT_LEFT_SHOULDER
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_RIGHT_SHOULDER,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            0.33f, 2.0f, 0.0f,
            JOINT_RIGHT_SHOULDER
        ))
    );

    float armAngle = (-60.0f + animationFactor * 100.0f) * pi / 180.0f;
    float handAngle = (-60.0f + animationFactor * 120.0f) * pi / 180.0f;
    float elbowX = 0.33f + 0.5f * cos(armAngle);
    float elbowY = 2.0f + 0.5f * sin(armAngle);
    float handX = 0.33f + 1.0f * cos(handAngle);
    float handY = 2.0f + 1.0f * sin(handAngle);

    pOISkeleton->addJointByType
    (
        JOINT_LEFT_ELBOW,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            -elbowX, elbowY, 0.0f,
            JOINT_LEFT_ELBOW
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_RIGHT_ELBOW,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            elbowX, elbowY, 0.0f,
            JOINT_RIGHT_ELBOW
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_LEFT_HAND,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            -handX, handY, 0.0f,
            JOINT_LEFT_HAND
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_RIGHT_HAND,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            handX, handY, 0.0f,
            JOINT_RIGHT_HAND
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_TORSO,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            0.0f, 1.5f, 0.0f,
            JOINT_TORSO
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_LEFT_HIP,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            -0.33f, 1.0f, 0.0f,
            JOINT_LEFT_HIP
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_RIGHT_HIP,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            0.33f, 1.0f, 0.0f,
            JOINT_RIGHT_HIP
        ))
    );

    float legAngle = (-90.0f + animationFactor * 30.0f) * pi / 180.0f;
    float kneeX = 0.33f + 0.5f * cos(legAngle);
    float kneeY = 1.0f + 0.5f * sin(legAngle);
    float footX = 0.33f + 1.0f * cos(legAngle);
    float footY = 1.0f + 1.0f * sin(legAngle);

    pOISkeleton->addJointByType
    (
        JOINT_LEFT_KNEE,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            -kneeX, kneeY, 0.0f,
            JOINT_LEFT_KNEE
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_RIGHT_KNEE,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            kneeX, kneeY, 0.0f,
            JOINT_RIGHT_KNEE
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_LEFT_FOOT,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            -footX, footY, 0.0f,
            JOINT_LEFT_FOOT
        ))
    );

    pOISkeleton->addJointByType
    (
        JOINT_RIGHT_FOOT,
        shared_ptr<OISkeletonJoint>(new OISkeletonJoint
        (
            footX, footY, 0.0f,
            JOINT_RIGHT_FOOT
        ))
    );

    const float devicePositionX = 0.0f;
    const float devicePositionY = 1.5f;
    const float devicePositionZ = 2.0f;
    const float deviceFOV = 90.0f;

    // Assumes all joint Z coordinates are 0 and that device points in -Z direction
    float planeX = tan(deviceFOV * 0.5f) * devicePositionZ * 2.0f;
    float planeY = frameHeight / frameWidth * planeX;

    for (int i = 0; i <= static_cast<int>(openiss::JointType::JOINT_RIGHT_FOOT); ++i)
    {
        auto joint = pOISkeleton->getJointByType(static_cast<openiss::JointType>(i));

        joint->x -= devicePositionX;
        joint->y -= devicePositionY;
        joint->z -= devicePositionZ;

        joint->col = joint->x + planeX * 0.5f;
        joint->row = frameHeight - (joint->y + planeY * 0.5f);

        bdBox[0].x = std::max(bdBox[0].x, joint->x);
        bdBox[0].y = std::max(bdBox[0].y, joint->y);
        bdBox[1].x = std::min(bdBox[0].x, joint->x);
        bdBox[1].y = std::min(bdBox[0].y, joint->y);
    }

    // Always tracked
    pOISkeleton->setSkeletonState(true);

    if(mpOIUserMap == nullptr)
    {
        mpOIUserMap = new OIUserMap(640, 480);
    }
}

} // namespace

// EOF
